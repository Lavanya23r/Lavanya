import React from 'react';
import "./DisplayList.css";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import FlipMove from 'react-flip-move';

function DisplayList(props) {
  const allItems = props.items;
  const listItems = allItems.map((Fitem)=>{
    return(
      <div className="displaystyle" key="Fitem.key">
      <p>
      <input type="text"
       id={Fitem.key}
       value={Fitem.text}
       onChange={(e) =>{            /* passing e as reference */
        props.makeUpdate(e.target.value, Fitem.key);
       }} />
      <span>
        <FontAwesomeIcon className="trashiconstyle"
        onClick={()=>{props.itemsDelete(Fitem.key);
        }}
        icon="trash" /> {/* or icon="fa-solid fa-trash" */}
      </span>
      </p>
      </div>
    )
  })
  return (
    <div>
    <FlipMove duration={400} easing="ease-in-out">
    {listItems}
    </FlipMove>
    </div>
  )
}

export default DisplayList;
