import React from 'react';
import './App.css';
import DisplayList from './DisplayList';
import { library } from '@fortawesome/fontawesome-svg-core';
import { faTrash } from '@fortawesome/free-solid-svg-icons';

library.add(faTrash);
class App extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      items: [],
      currentItem: {
        text:"",
        key:""
      }
    }
  }

  focususerInput=(e)=>{
    this.setState({
      currentItem:{
        text: e.target.value,
        key: Date.now()  /*for unique purpose */
      }
    })
  }

  addButton=(e)=>{
    e.preventDefault();
    const newItem = this.state.currentItem; /* holding currentItem data in new variable called newItem */
    console.log(newItem);
    if(newItem.text !== ""){  /* if user input box is not empty(entered), place */
      const newItems = [newItem, ...this.state.items]; /* rest operator fro array elememts */
      console.log(newItems);
      this.setState({
        items: newItems, /* Now Array position will be updated bcoz we kept in setstate */
        currentItem: {   /* To empty the user input after add submitting */
          text: "",
          key: ""
        }
      })
    }
  }

  deleteTodo = (key) =>{
    const deletePlan = this.state.items.filter((delItems)=>delItems.key !== key);
    this.setState({
      items: deletePlan
    })
  }

  updateTodo = (text,key) =>{
    const updatePlan = this.state.items;
    updatePlan.map((item)=>{
      if(item.key === key){
        item.text = text;
      }
    })
    this.setState({
      updateitem: updatePlan
    })
  }

  render() {
    return (
      <div className="App">
        <header>
          <form id="to-do-form" onSubmit={this.addButton}>
          <br/>
          <h3>React ToDoList</h3>
            <input type="text" placeholder="Todays work plan" value={this.state.currentItem.text}
                                                              onChange={this.focususerInput}/>
            <button type="submit">+</button>
          </form>
          <DisplayList items={this.state.items} itemsDelete={this.deleteTodo} makeUpdate={this.updateTodo} />
        </header>
      </div>
    )
  }
}

export default App;
