import { combineReducers } from "redux";
import errorReducer from "./errorReducer";
import addcarReducer from "./addcarReducer";
export default combineReducers({
    errors: errorReducer,
    projects: addcarReducer,
});