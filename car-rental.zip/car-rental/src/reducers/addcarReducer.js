import { GET_PROJECTS, GET_UPDATE, DELETE_PROJECT, CART_UPDATE } from "../actions/types";

const initialState = {
    projects:[],
    project:{}
};
export default function(state=initialState,action){
    switch(action.type){
        case GET_PROJECTS:
            return {
                ...state,
                projects:action.payload
            };
            case GET_UPDATE:
            return {
                ...state,
                project:action.payload,
            };
            case DELETE_PROJECT:
            return {
                ...state,
                projects: state.projects.filter(project=> project.id!=action.payload),
            };
            case CART_UPDATE:
            return {
                ...state,
                project: action.payload,
            };
            default:
                return state;
    }
}
