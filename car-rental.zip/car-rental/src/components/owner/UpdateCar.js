import React, { Component } from 'react';
import { getUpdate, createCar } from './../../actions/CarAction';
import { connect } from 'react-redux';
import { PropTypes } from 'prop-types';

 class UpdateCar extends Component {
    constructor(props){
        super(props);
        this.state={
            carName: "",
            availablility: "",
            totalcars: "",
            imageone: "",
            id: ""
        };
    }

    componentDidMount(){
        const {id} = this.props.match.params;
        this.props.getUpdate(id);
    }

    componentWillReceiveProps(nextProps){
        const {
            carName,
            availablility,
            totalcars,
            imageone,
            id,
        } = nextProps.project;
        this.setState({
            carName,
            availablility,
            totalcars,
            imageone,
            id,
          });
        }
    
        onChangeEvent=(e)=>{
            this.setState({[e.target.name]: e.target.value});
           };

           onSubmitHandler=(e)=>{
            e.preventDefault();
            const updatedData = {
            carName:this.state.carName,
            availablility:this.state.availablility,
            totalcars:this.state.totalcars,
            imageone:this.state.imageone,
            id:this.state.id
            };
            
            this.props.createCar(updatedData,this.props.history);
          }

    render() {
        return (
            <div>
            <div className='container'>
            <div className='row'>
            <div className='col-8 mx-auto'>
            <h4 className='text-center'>Update Car</h4>
             <form onSubmit={this.onSubmitHandler}>
             <div className="form-group">
               <label>Name</label>
               <input type="text" className="form-control" id="exampleFormControlInput1" 
               name="carName" value={this.state.carName} onChange={this.onChangeEvent}
                placeholder="Name"/>
                <p></p>
             </div><br/>
             
             <div className="form-group">
               <label for="exampleFormControlTextarea1">Availability</label>&nbsp;<br/>
               <input type="text" className="form-control" name="availablility" value={this.state.availablility}
               onChange={this.onChangeEvent} placeholder="status"/>
                
             </div><br/>
             <div className="form-group">
               <label for="exampleFormControlSelect1">No of Cars</label>
               <input type="number" name="totalcars" 
               value={this.state.totalcars} onChange={this.onChangeEvent}
               className='form-control'/>
              
             </div><br/>
             <div className="form-group">
          <input type="file" className="form-control-file" name="imageone"
          value={this.state.imageone} onChange={this.onChangeEvent}
           />
          
        </div><br/>
        <input type="submit" className='btn btn-primary' value="Submit"/>
           </form>
             </div></div>
             </div>
            </div>
        )
    }
}

UpdateCar.propTypes={
    getUpdate:PropTypes.func.isRequired,
    createCar:PropTypes.func.isRequired,
    project:PropTypes.object.isRequired
};
const mapStateToProps = (state) => ({
    project: state.projects.project,
});

export default connect(mapStateToProps,{getUpdate,createCar})(UpdateCar);