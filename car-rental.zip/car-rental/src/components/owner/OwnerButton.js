import React from "react"
import { Link } from "react-router-dom";

const OwnerButton=()=>{
    return(
        <Link to="/ownerDashboard" className="btn btn-lg btn-info">
         Agency Owner
        </Link>
    );
}

export default OwnerButton;