import React from 'react'
import CarOperations from './CarOperations';
import { Link } from 'react-router-dom';
function AllOperations() {
    return (
        <div>
        <div className="row">
  <div className="col-3">
    <div className="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <Link className="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="" aria-selected="true">Add details</Link>
      <a className="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile"  aria-selected="false">List of cars</a>
      <a className="nav-link" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" aria-selected="false">Check Booking</a>
      <a className="nav-link" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings"  aria-selected="false">Settings</a>
    </div>
  </div>
  <div className="col-9">
    <CarOperations/>
</div>
</div>
      
        </div>
    )
}
export default AllOperations;
