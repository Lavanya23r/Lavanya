import React, { Component } from 'react'
import { Link } from 'react-router-dom';
import { deleteProject } from '../../actions/CarAction';
import { connect } from 'react-redux';
import { PropTypes } from 'prop-types';

 class CarItems extends Component {

    onDeleteEvent =(id) => {
        this.props.deleteProject(id);
    };

    render() {
            const { project } = this.props;
        return (
            <div>
                
                <div className='container text-center'>
                <div className='card pt-3'>
                <div className='row'>

                <div className='col-sm-2'>
                 <h5>{project.carName}</h5>
                 </div>

                <div className='col-3'>
                <h5>{project.availablility}</h5>
                </div>

                <div className='col-2'>
                <h6>{project.totalcars}</h6><br/>
                </div>

                <div className='col-1'>
                <h6>{project.cartype}</h6><br/>
                </div>

                <div className='col-2'>
                <Link to={`/updateCar/${project.id}`} className="btn btn-sm btn-success">Update</Link>
                </div>

                <div className='col-2'>
                <a className="btn btn-sm btn-danger" 
                onClick={this.onDeleteEvent.bind(this,project.id)}>Delete</a>
                </div>
                </div>
                </div>
            </div><br/>
            </div>
        );
    }
}
CarItems.propTypes = {
    deleteProject: PropTypes.func.isRequired,
};

export default connect(null,{deleteProject})(CarItems);
