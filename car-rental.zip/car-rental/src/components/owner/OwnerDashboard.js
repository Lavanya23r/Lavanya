import React from "react"
import { Link } from "react-router-dom";

const OwnerDashboard=()=>{
    return(
        <div className="container owner-item">
        <div className="row">
            <div className="col-md-6 ">
                <div className="card text-center owner-one">
                    <img src="img1.jpg" className="card-img-top" alt="..."/>
                    <div className="card-body">
                     <Link to="/listCars" className="btn btn-info">Car Operations</Link>
                    </div>
                  </div>
            </div>
            <div className="col-md-6">
                <div className="card text-center owner-two">
                    <img src="img1.jpg" className="card-img-top" alt="..."/>
                    <div className="card-body">
                     <Link to="/checkBooking" className="btn btn-info">Check Booking</Link>
                    </div>
                </div>
            </div>
            </div>
        </div>

     
        
    );
}

export default OwnerDashboard;