import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from "prop-types";
import { getProjects } from "../../actions/CarAction";
import CarItems from './CarItems';
import { Link } from 'react-router-dom';

 class ListCars extends Component {
    componentDidMount(){
        this.props.getProjects();
    }
    render() {
        const { projects } = this.props.projects;
        return (
            
            <div>
            <div className='container mb-3'>
            <div className='row'>
            <div className='col-md-9'>
            <h4 className='text-center'>List of Cars</h4></div>

            <div className='col-md-3'>
            <Link to="/carOperations" className="btn btn-info">Add Car</Link>
            </div>
           </div>
        </div>
            {projects.map((project) => {
                return <CarItems key={project.id} project={project} />;
            })}
            
            </div>
        )
    }
}

ListCars.propTypes = {
    getProjects: PropTypes.func.isRequired,
    projects: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => ({
    projects: state.projects,
});

export default connect(mapStateToProps, {getProjects})(ListCars);
