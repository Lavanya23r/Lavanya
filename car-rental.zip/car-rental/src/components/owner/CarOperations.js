import React, { Component } from 'react'
import { connect } from 'react-redux';
import { createCar } from '../../actions/CarAction';
import PropTypes from "prop-types";
import axios from 'axios';
 class CarOperations extends Component {
  constructor(props) {
    super(props);
    this.state={
      carName:"",
      availablility:"",
      totalcars:"",
      cartype:"",
      errors:{}
    };
  }

  componentWillReceiveProps(nextProps){
    if(nextProps.errors){
      this.setState({
        errors: nextProps.errors,
      });
    }
  }

    onChangeEvent=(e)=>{
     this.setState({[e.target.name]: e.target.value});
    };

    onSubmitHandler=(e)=>{
      e.preventDefault();
      const newData = {
      carName:this.state.carName,
      availablility:this.state.availablility,
      totalcars:this.state.totalcars,
      cartype:this.state.cartype
      };
      //console.log("Entered",newData);
      this.props.createCar(newData,this.props.history);
    }

    render(){
      const {errors} = this.state;
    return (
       <div>
      <div className='container'>
      <div className='row'>
      <div className='col-8 mx-auto'>
      <h4 className='text-center'>Add Car</h4>
       <form onSubmit={this.onSubmitHandler}>
       <div className="form-group">

         <label>Name</label>
         <input type="text" className="form-control" id="exampleFormControlInput1" 
         name="carName" value={this.state.carName} onChange={this.onChangeEvent}
          placeholder="Name"/>
          <p>{errors.carName}</p>
       </div><br/>
       
       <div className="form-group">
         <label for="exampleFormControlTextarea1">Availability</label>&nbsp;<br/>
         <input type="text" className="form-control" name="availablility"
          value={this.state.availablility} onChange={this.onChangeEvent} placeholder="status"/>
          <p>{errors.availablility}</p>
       </div><br/>

       <div className="form-group">
         <label for="exampleFormControlSelect1">No of Cars</label>
         <input type="number" name="totalcars" value={this.state.totalcars}
          onChange={this.onChangeEvent}
         className='form-control'/>
         <p>{errors.totalcars}</p>
       </div><br/>

       <div className="form-group">
       <label for="exampleFormControlSelect1">Car Type</label>
       <div className="dropdown">
        <select name="cartype" value={this.state.cartype} onChange={this.onChangeEvent} className='form-control' >
        <option value="Volvo" >Volvo</option>
        <option value="BMW">BMW</option>
        <option value="Audi">Audi</option>
        <option value="Benz">Benz</option>
        </select>
      </div>
       </div>
      <br/>

  <input type="submit" className='btn btn-primary' value="submit"/>
     </form>
       </div>
     </div>
    </div>
   </div>
    )
}
}

  CarOperations.propTypes = {
  createCar: PropTypes.func.isRequired,
  errors: PropTypes.object.isRequired
  };

  const mapStateToProps=(state)=>({
  errors: state.errors,
  });

  export default connect(mapStateToProps,{createCar})(CarOperations);

