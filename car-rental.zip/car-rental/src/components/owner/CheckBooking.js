import React, { Component } from 'react'

 class CheckBooking extends Component {
    render() {
        return (
            <div>
              //booking  
            </div>
        )
    }
}
export default CheckBooking;
