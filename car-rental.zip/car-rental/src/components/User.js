import React, { Component } from 'react'
import { Link } from 'react-router-dom';

 class User extends Component {
    render() {
        return (
            <div>
      <div className="card bg-dark mt-4">
      <img src="./img1.jpg" class="card-img" alt="..."/>
        <div className="card-img-overlay">

    <section id="home-section" className='py-5 mt-5'>
    <div className='container'>
      <div className='row'>
       <div className='col-md-8 order-1'>
         <h1>Rent a Car Online Today &</h1>
         <h1>Enjoy the Best deals, Rates.</h1><br/>
         <h5>We are open 24/7 including major holidays</h5>
       </div>
      </div>
    </div>
    </section>
    
  </div>
</div>        
      </div>
        )
    }
}
export default User;
