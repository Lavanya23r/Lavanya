import React, { Component } from 'react'
import CustomerButton from './customer/CustomerButton';
import OwnerButton from './owner/OwnerButton';

 class Users extends Component {
    render() {
        return (
            
            <div className="container projects">
                <div className="row">
                  <h1 className="display-6"></h1>
                  <br/><br/>
                    <div className="col-md-8">  
                        <OwnerButton/>
                    </div>
                    <div className="col-md-4">  
                        <CustomerButton/>
                    </div>

                </div>
            </div>
        
        )
    }
}
export default Users;
