import React, { Component } from 'react'

 class Landing extends Component {
  render() {
    return (
      
      <div className="card land-page">
      <img src="./img1.jpg" className="card-img" alt="..."/>
      <div className="card-img-overlay">

    <section id="home-section" className='py-5 mt-5'>
    <div className='container'>
      <div className='row'>
       <div className='col-md-8 order-1'>
         <h1>Rent a Car Online Today &</h1>
         <h1>Enjoy the Best deals, Rates.</h1><br/>
         <h5>We are open 24/7 including major holidays</h5>
       </div>
      </div>
    </div>
    </section>
    
  </div>
</div>        
      
    )
  }
}
export default Landing;