import React, { Component } from 'react';
import { Link } from 'react-router-dom';

 class CustomerItems extends Component {
    render() {
        const { project } = this.props;
        return (
            
            
            <div className='col-sm-3 cust-items text-center'>
            <div className='card'>
            <img className='card-img-top' src="./car1.jpg"/>
            <div className='card-body'>
                <h5>{project.carName}</h5>
                <h5>{project.availablility}</h5>
                <h6>{project.totalcars}</h6>
                <h5>{project.cartype}</h5>
                <Link to={`/addCart/${project.carName}`} className="btn btn-info">Add to Cart</Link>
                &nbsp;&nbsp;
                <Link to="/" className="btn btn-info">Book Now</Link>   
            </div></div>
            </div> 
            
        )
    }
}
export default CustomerItems;