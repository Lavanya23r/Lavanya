import React from 'react'
import { auth } from '../../firebase';
import CustomerDashboard from './CustomerDashboard';

const Login=()=> {
    return (
        <div>
        <button onClick={() => auth.signOut()} className='btn btn-info log-per'>Logout</button>
            <CustomerDashboard/> <br/>
            
        </div>
    )
}
export default Login;
