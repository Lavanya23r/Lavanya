import React from "react"
import { Link } from "react-router-dom";

const CustomerButton=()=>{
    return(
        <Link to="/customerPage" className="btn btn-lg btn-info">
         Customer
        </Link>
    );
}

export default CustomerButton;