import React,{useEffect, useState} from 'react';
import { auth } from '../../firebase';
import UserAuth from './UserAuth';
import Login from './Login';

  const CustomerPage=() =>{
    const[presentUser, setPresentUser] = useState(null);
     useEffect(()=>{
      auth.onAuthStateChanged(user =>{
      if(user){
       setPresentUser({
        uid:user.uid,
        email:user.email
      })
      }
      else{
      setPresentUser(null);
      }
      })
    },[])



     return (
     <div>
       {presentUser ? <Login/> : <UserAuth/> }
     </div>
   )
 }

export default CustomerPage;
