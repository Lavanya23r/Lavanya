import React, { useState } from 'react'
import { Link } from 'react-router-dom';
import { auth } from '../../firebase';

 const UserAuth = ()=> {
    const [data, setData] = useState({
        email:"",
        password:""
    })
    const {email,password} = data;
    const changeHandler = e =>{
        setData({...data,[e.target.name]:e.target.value})
    }
    const register = e =>{
        e.preventDefault();
        auth.createUserWithEmailAndPassword(email,password).then(
            user => console.log(user)
            ).catch(err => console.log(err))
    }
    const login = e =>{
        e.preventDefault();
        auth.signInWithEmailAndPassword(email,password).then(
            user => console.log(user)
            ).catch(err => console.log(err))
    }
        return (
            <div className="container register" >
            <div className="row">
             <div className="col-md-3 register-left">
            
            <h3></h3>
            
        </div>
        <div className="col-md-5 register-right" autoComplete="off">
            <div className="tab-content" id="myTabContent">
                <div className="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <h3 className="register-heading">Welcome</h3>
                    <div className="row register-form">
                        <div className="col-md-11">
                            
                            <div className="form-group">
                              <input type="email" className="form-control"
                              name="email" value={email} placeholder="Your Email" onChange={changeHandler} />
                          </div>
                            <br/>
                            <div className="form-group">
                                <input type="password" name="password" value={password}
                                className="form-control" placeholder="Password" onChange={changeHandler} />
                            </div>
                            <br/>
        
                            <input type="submit" className="btnRegister"  value="Register" onClick={register}/>
                          <input type="submit" className="btnLogin"  value="Login" onClick={login}/>
                        </div>  
                        <Link to="/login" className="nav-link"  
                        aria-controls="login" 
                       aria-selected="false"></Link>                    
                        </div>
                    
                </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }


export default UserAuth;
