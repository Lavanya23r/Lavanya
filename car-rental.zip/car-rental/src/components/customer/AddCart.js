import React, { Component } from 'react'

 class AddCart extends Component {
    render() {
        return (
            <div>
                <div className='col-md-3 card text-center'>

                <h5>Audi</h5>
                <h5>Available</h5>
                <h6></h6>
                </div>
            </div>
        )
    }
}
export default AddCart;