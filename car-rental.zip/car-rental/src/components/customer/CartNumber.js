import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

 const CartNumber=({products}) => {
    return (
        <div>
        
        <Link to="">
        <i className='fas fa-shopping-cart cart-item'>
        <span className='position-absolute top-0 start-100 translate-middle
         badge rounded-pill bg-danger'>{products.length}</span></i></Link>
        </div>
    )
}

const mapStateToProps = state => ({
    products : state
})

export default connect(mapStateToProps)(CartNumber);