import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from "prop-types";
import { getProjects } from "../../actions/CarAction";
import CustomerItems from './CustomerItems';
import CartNumber from './CartNumber';

 class CustomerDashboard extends Component {
    componentDidMount(){
        this.props.getProjects();
    }
    render() {
        const { projects } = this.props.projects;
        return (
            <div>
            <div className='container '>
            <div className='row'>
            <div className='col-md-10'>
            <h4 className='text-center'>Customer Dashboard</h4></div>
            <div className='col-md-2 '>
                <CartNumber/>
            </div></div></div>
            {projects.map((project) => {
                return <CustomerItems key={project.id} project={project} />;
            })}
            </div>
            
        )
    }
}

CustomerDashboard.propTypes = {
    getProjects: PropTypes.func.isRequired,
    projects: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => ({
    projects: state.projects,
});

export default connect(mapStateToProps, {getProjects})(CustomerDashboard);
