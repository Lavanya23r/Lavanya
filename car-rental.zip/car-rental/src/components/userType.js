import React, { Component } from 'react'

 class userType extends Component {
    render() {
        return (
            <div>
            <h1></h1>
            <div className='container'>
            <div className='row'>
             <div className='col-md-6'>
             <button type="button" class="btn btn-info">User</button><br/>
             </div>
             <div className='col-md-6'> 
             <button type="button" class="btn btn-info">User</button><br/>
            </div>
            </div>
            </div>
            </div>
        )
    }
}
export default userType;