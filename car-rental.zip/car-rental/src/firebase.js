import firebase from "firebase";

const firebaseConfig = {
    apiKey: "AIzaSyBPb93R8wG3F4UlhcxmxSLF9vS-n_0SDds",
    authDomain: "carproject-fe6cc.firebaseapp.com",
    databaseURL: "https://carproject-fe6cc-default-rtdb.firebaseio.com",
    projectId: "carproject-fe6cc",
    storageBucket: "carproject-fe6cc.appspot.com",
    messagingSenderId: "34515699804",
    appId: "1:34515699804:web:59a3c74316a989ae657e99"
  };
  
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  const db = firebase.firestore();
  const auth= firebase.auth();

  export {auth};

  export default db;