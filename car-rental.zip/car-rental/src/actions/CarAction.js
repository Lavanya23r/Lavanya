import axios from "axios";
import { GET_ERRORS, GET_PROJECTS, GET_UPDATE, DELETE_PROJECT, CART_UPDATE} from "./types";

export const createCar = (carowner, history)=> async(dispatch)=>{
    try{
        const res = await axios.post("http://localhost:3000/carowner",carowner);
        history.push("/listCars");
    }catch(error){
        dispatch({
            type:GET_ERRORS,
            payload:error.response.data
        });
    }
};

export const getProjects=()=> async(dispatch)=>{
   const res = await axios.get("http://localhost:3000/carowner");
   dispatch({
       type:GET_PROJECTS,
       payload:res.data,
   });
};

export const getUpdate=(id)=> async(dispatch)=>{
    const res = await axios.get(`http://localhost:3000/carowner/${id}`);
    dispatch({
        type:GET_UPDATE,
        payload:res.data,
    });
 };

 export const deleteProject=(id)=> async(dispatch)=>{
    const res = await axios.delete(`http://localhost:3000/carowner/${id}`);
    dispatch({
        type:DELETE_PROJECT,
        payload:id,
    });
 };

 export const cartProject =(carName)=> async(dispatch)=>{
    const res = await axios.get(`http://localhost:3000/carowner/${carName}`);
    dispatch({
        type:CART_UPDATE,
        payload:res.data,
    });
 };
