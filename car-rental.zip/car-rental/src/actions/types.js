export const GET_ERRORS = "GET_ERRORS";
export const GET_PROJECTS = "GET_PROJECTS";
export const GET_UPDATE = "GET_UPDATE";
export const DELETE_PROJECT = "DELETE_PROJECT";
export const CART_UPDATE = "CARt_UPDATE";
