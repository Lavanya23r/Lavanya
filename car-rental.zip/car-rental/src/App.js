import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import React from 'react';
import {BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Landing from './components/Landing';
import Header from './components/layout/Header';
import Users from './components/Users';
import OwnerDashboard from './components/owner/OwnerDashboard';
import CustomerPage from './components/customer/CustomerPage';
import Login from './components/customer/Login';
import CustomerDashboard from './components/customer/CustomerDashboard';
import CarOperations from './components/owner/CarOperations';
import CheckBooking from './components/owner/CheckBooking';

import { Provider } from "react-redux";
import store from './store';
import AllOperations from './components/owner/AllOperations';
import ListCars from './components/owner/ListCars';
import AddCart from './components/customer/AddCart';
import UpdateCar from './components/owner/UpdateCar';

function App() {
  return (
    <Provider store={store}>
    <Router>
    <Header/>
    <Routes>
     <Route exact path="/landingPage" element={<Landing/>} />
     <Route exact path="/users" element={<Users/>} />
     <Route exact path="/ownerDashboard" element={<OwnerDashboard/>} />
     <Route exact path="/allOperations" element={<AllOperations/>} />
     <Route exact path="/customerPage" element={<CustomerPage/>} />
     <Route exact path="/login" element={<Login/>} />
     <Route exact path="/customerDashboard" element={<CustomerDashboard/>} />
     <Route exact path="/caroperations" element={<CarOperations/>} />
     <Route exact path="/checkBooking" element={<CheckBooking/>} />
     <Route exact path="/listCars" element={<ListCars/>} />
     <Route exact path="/addCart/:carName" element={<AddCart/>} />
     <Route exact path="/updateCar/:id" element={<UpdateCar/>} />
     </Routes>
    </Router>
    </Provider>
   
  );
}

export default App;
