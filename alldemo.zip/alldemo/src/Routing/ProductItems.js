import React, {useState} from 'react';
import { Link } from 'react-router-dom';

const ProductItems = function(){
var[items] = useState([
    {name:"Lav", color:"Fair"},
    {name:"Vaj", color:"Black"},
    {name:"Aishu", color:"White"},
    {name:"Nik", color:"Red"},
])
    return(
        <ol>
            {
                items.map((p,i)=>{
                    return(
                        <ol>
                        <Link to={`/details/${JSON.stringify(p)}`}>{p.name}</Link>
                        </ol>
                    )
                })
            }
        </ol>
    )
}
export default ProductItems;