import React from 'react'

const AboutUs=function() {
  return (
    <div>Welcome to AboutUs</div>
  )
}

export default AboutUs;