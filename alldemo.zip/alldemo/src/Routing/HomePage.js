import React from 'react'

const HomePage = function() {
  return (
    <div>Welcome to HomePage</div>
  )
}

export default HomePage;