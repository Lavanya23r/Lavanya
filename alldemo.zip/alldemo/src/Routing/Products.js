import React, { useState } from 'react';

const Products = function(){
var[items] = useState([
    "blue", "green", "red"
]);
return(
    <div>
        <ol>
            {
                items.map((p,i)=>{
                    return(
                        <ol>{p}</ol>
                    )
                })
            }
        </ol>
    </div>
)
}
export default Products;