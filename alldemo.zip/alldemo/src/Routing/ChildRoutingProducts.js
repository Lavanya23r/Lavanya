import React, {useState} from 'react';
import { Routes, Route, Link, useRoutes, BrowserRouter as Router } from 'react-router-dom';
import ChildRoutingDetails from './ChildRoutingDetails';

const ChildRoutingProducts = function(){
var[items] = useState([
    {name:"Lav", color:"Fair"},
    {name:"Vaj", color:"Black"},
    {name:"Aishu", color:"White"},
    {name:"Nik", color:"Red"},
])

var {url, path} = useRoutes();
    return(
        <div>
        <Router>
        <h1>hello</h1>
        <ol>
            {
                items.map((p,i)=>{
                    return(
                        <ol>
                        <li>Productitemss</li>
                        <Link to={`${url}/childroutingdetails/${JSON.stringify(p)}`}>{p.name}</Link>
                        </ol>
                    )
                })
            }
        </ol>
        
        <Routes>
        <Route exact path={`${path}/childroutingdetails/:pro`} element={<ChildRoutingDetails/>}></Route>
        </Routes>
        </Router>
        </div>
    )
}
export default ChildRoutingProducts;