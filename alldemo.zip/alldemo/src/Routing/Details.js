import React from 'react';
import { useParams } from 'react-router-dom';

const Details = function(){
    var{pro} = useParams();
    pro = JSON.parse(pro);

    return(
        <div>
        <h3>{pro.name}</h3>
        <h3>{pro.color}</h3>
        </div>
    )
}

export default Details;