import React from 'react'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import HomePage from './HomePage';
import AboutUs from './AboutUs';
import ProductItems from './ProductItems';
import Details from './Details';

function Routing() {
  return (
      
    <div>
    <BrowserRouter>
    <h1>Welcome to Routing</h1>
    <ul>
        <li>
        <Link className='active' to='/home'>Home</Link>
        </li>
        <li>
        <Link className='active' to='/about'>AboutUs</Link>
        </li>
        <li>
        <Link className='active' to='/productsItems'>ProductItems</Link>
        </li>
    </ul>
        
        <Routes>
        <Route path='/home' element={<HomePage/>}></Route>
        <Route path='/about' element={<AboutUs/>}></Route>
        <Route exact path='/productsItems' element={<ProductItems/>}></Route>
        <Route exact path='/details/:pro' element={<Details/>}></Route>

        </Routes>
    </BrowserRouter>
    </div>
  )
}

export default Routing;