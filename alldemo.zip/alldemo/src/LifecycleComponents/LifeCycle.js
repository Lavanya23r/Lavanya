import React from "react";

class LifeCycle extends React.Component{
    constructor(){
        super();
        console.log("constructor");

        this.state={
            num:0
        };
    }

    NumberHandler=()=>{
        this.setState({
            num:this.state.num + 1
        })
    }

    componentWillMount=()=>{
        console.log("component will mount");
    }

    componentDidMount=()=>{
        console.log("component did mount");
    }

    shouldComponentUpdate=()=>{
        console.log("should component update");
        return true;
    }

    componentWillUpdate=()=>{
        console.log("component will update");
    }

    componentDidUpdate=()=>{
        console.log("component did update");
    }

    render(){
        console.log("rendered");
        return(
            <div>
            <button onClick={this.NumberHandler}>Lifecycle</button>
            {this.state.num}
            </div>
        )
    }
}

export default LifeCycle;