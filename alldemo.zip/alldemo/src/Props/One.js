import react from "react";
import Two from "./Two";

function One(){
    return(
        <div>
            <Two name="Lav"
                 color="White"
                 food="Mango"
                 image="mango.jpg"
            />

            <Two name="Jams"
                 color="Blue"
                 food="Orange"
                 image="Orange.jpg"
            />

            <Two name="Mike"
                 color="Black"
                 food="Guava"
                 image="guava.jpg"
            />
        </div>
    );
}

export default One;