import React from "react";

function Two(props){
    return(
        <div className="cursor">
            <h1>{props.name}</h1>
            <img src={props.image} />
            <h2>{props.color}</h2>
            <h2>{props.food}</h2>
        </div>
    );
}

export default Two;