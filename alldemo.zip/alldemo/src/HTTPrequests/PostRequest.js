import React, { Component } from 'react'
import axios from 'axios';

class PostRequest extends Component {
constructor(){
    super();
    this.state={
        userId:"",
        title:"",
        body:""
    }
}

stateHandler = (e) =>{
    this.setState({
        [e.target.name]:[e.target.value]
    })
}

postData = (e) =>{
    e.preventDefault();
    console.log(this.state);
    axios.post("https://jsonplaceholder.typicode.com/posts").then(
        (response)=>{
            console.log(response);
        }
    )
    .catch((error)=>{
        console.log(error);
    })

}

  render() {
      const{userId, title, body} =this.state;
    return (
      <div>
      <h4>Post Request call</h4>
      <form>
      <div>
        User Id: <input type="text" name="userId" value={userId}
                                                  onChange={this.stateHandler} />
      </div>
      <div>
        Title: <input type="text" name="title" value={title}
                                                  onChange={this.stateHandler} />
      </div>
      <div>
        Body: <input type="text" name="body" value={body}
                                                  onChange={this.stateHandler} />
      </div>
      <button className="hbutton" onClick={this.postData}>Post button</button>
      </form>
      </div>
    )
  }
}

export default PostRequest