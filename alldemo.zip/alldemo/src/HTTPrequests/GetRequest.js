import axios from 'axios';
import React, { Component } from 'react'

class GetRequest extends Component {
constructor(){
    super();
    this.state = {
        name:""
    }
}

getData = () =>{
    axios.get("https://jsonplaceholder.typicode.com/posts/1").then(
        (response)=>{
            console.log(response.data);
            this.setState({
                name: response.data
            })
        }
    )
    .catch((error)=>{
        console.log(console.error);
    })
}

  render() {
    return (
      <div>
        <h4>Get calls</h4>
        <p>User Id: {this.state.data}</p>
        <p>Title: {this.state.data}</p>
        <button className='trbutton' onClick={this.getData}>Button</button>
      </div>
    )
  }
}


export default GetRequest;