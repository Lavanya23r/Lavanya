import React from "react";
import FunctionalComponent from './FunctionalComponent';
import AnotherClass from "./AnotherClass";

class ClassComponent extends React.Component{
    render(){
        return(
            <div>
            <AnotherClass name="class props" />
            <FunctionalComponent name="functional props" />
            </div>
        )
    }
}

export default ClassComponent;