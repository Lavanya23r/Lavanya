import React from "react";

class AnotherClass extends React.Component{
render(){
    return(
        <div>
        {this.props.name}
        </div>
    )
}
}

export default AnotherClass;