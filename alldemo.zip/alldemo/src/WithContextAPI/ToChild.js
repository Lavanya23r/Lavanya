import React, { Component } from 'react'
import { abc } from './GrandParent'

class ToChild extends Component {
  render() {
    return (
        <div className='child'>
        <h1>Child</h1>
        <abc.Consumer>
        {
          mydata => {
            return <h3>{mydata.one} and {mydata.two}</h3>
          }
        }
        </abc.Consumer>
        <img src="mango.jpg" width="250" height="130" />
        </div>
    )
  }
}

export default ToChild