import React, { Component } from 'react'
import ToChild from './ToChild'

class ToParent extends Component {
  render() {
    return (
        <div className='parent'>
        <h1>Parent</h1>
        <img src="orange.jpg" width="250" height="130" />
        </div>
    )
  }
}

export default ToParent