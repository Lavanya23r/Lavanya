import React, { Component } from 'react'
import ToChild from './ToChild';

export const abc=React.createContext();

class GrandParent extends Component {
 constructor(){
     super();
     this.state = {
        myself: {one:"happy", two:"freedom"}
     }
 }

  render() {
    return (
      <div className='grand'>
      <h2>Grandpaa</h2>
      <abc.Provider value={this.state.myself}>
      <ToChild />
      </abc.Provider>
      <img src="apple.jpg" width="250" height="130" />
      </div>
    )
  }
}

export default GrandParent;