import React, { Component } from 'react'
class FormHandling extends Component {
    constructor(props) {
      super(props)
    
      this.state = {
         name:"",
         enter:"",
         color:""
      }
    }

    NameChangeHandler=(e)=>{
        this.setState({
            name: e.target.value
        })
    }    
    
    EnterTextHandler=(e)=>{
        this.setState({
            enter:e.target.value
        })
    }

    ColorHandler=(e)=>{
        this.setState({
            color:e.target.value
        })
        
    }


    SubmitHandler=(event)=>{
        alert(`${this.state.name} ${this.state.enter} ${this.state.color}`)
        event.preventDefault()
    }

  render() {
    return (
      <div>
      <form className='appone' onSubmit={this.SubmitHandler}>
      <div align="center">
      <label>Name</label>&nbsp;&nbsp;
      <input type="text" value={this.state.name} onChange={this.NameChangeHandler}/>
      </div><br/>
      <div align="center">
      <label>Enter Text</label>&nbsp;&nbsp;
      <textarea value={this.state.enter} onChange={this.EnterTextHandler} />
      </div><br/>
      <div align="center">
      <label>Color</label>&nbsp;&nbsp;
      <select value={this.state.color} onChange={this.ColorHandler}>
      <option value="Green">Green</option>
      <option value="Pink">Pink</option>
      <option value="Black">Black</option>
      </select>
      </div><br/>
      <button>Submit</button>
      </form>
      </div>
    )
  }
}

export default FormHandling;