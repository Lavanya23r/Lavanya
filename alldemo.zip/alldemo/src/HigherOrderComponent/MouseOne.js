import React, { Component } from 'react'
import Common from './Common'

class MouseOne extends Component {
  render() {
    return (
      <div>
      <h3 onMouseOver={this.props.IncCnt}>Mouse over {this.props.cnt}</h3>
      </div>
    )
  }
}

export default Common(MouseOne);