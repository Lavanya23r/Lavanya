import React, { Component } from 'react'
import Common from './Common'

class Button extends Component {
  render() {
    return (
      <div>
        <button onClick={this.props.IncCnt}>
        ClikMe {this.props.cnt}
        </button>
      </div>
    )
  }
}

export default Common(Button);