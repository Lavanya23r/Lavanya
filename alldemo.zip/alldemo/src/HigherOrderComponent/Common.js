import React from 'react';

const Common = function(Mouse){

class NewComponent extends React.Component{
    constructor(){
        super();
        this.state ={
            count:0
        }
    }

    IncrementHandler =() =>{
        this.setState({
            count: this.state.count + 1
        })
    }

    render(){
        return(
            <div>
            <Mouse cnt={this.state.count} IncCnt={this.IncrementHandler}></Mouse>
            
            </div>
        )
    }
    
}
 return NewComponent;
}

export default Common;
