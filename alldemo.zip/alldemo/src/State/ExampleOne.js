import React from "react";

class ExampleOne extends React.Component{
    constructor(){
        super();
        this.state={color: "green", dress:"top"};
        console.log(this);

    }

    render(){
        return(
            <div>
            <h2>{this.state.color}</h2>
            <h2>{this.state.dress}</h2>
            </div>
        );
    }
}

export default ExampleOne;