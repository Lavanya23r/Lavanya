import React from "react";

class PrevStatecomp extends React.Component{
    constructor(){
        super();
        this.state= {counter:0}
    }

    previousMethod=(userVal)=>{
        this.setState((prevState, props)=>{
            console.log("preval",prevState);
            return{counter:this.state.counter + userVal }
        })
    }


    render(){
        console.log("newval", this.state.counter);
        return(
    
            <div>
            <button onClick={()=>this.previousMethod(10)}>Next:{this.state.counter}</button>
            </div>
        )
    }
}

export default PrevStatecomp;