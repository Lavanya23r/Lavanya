import React from "react";

class ExampleTwo extends React.Component{
    constructor(){
        super();
        this.state={counter:0}
    }

    changeMethod=()=>{
        this.setState({
            counter: this.state.counter + 1
        })
        console.log(this.state.counter);
    }

    render(){
        return(
            <div>
             <button className="button" onClick={this.changeMethod}>Counter:{this.state.counter}</button>
            </div>
        );
    }

}

export default ExampleTwo;