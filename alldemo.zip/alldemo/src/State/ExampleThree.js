import React from "react";

class ExampleThree extends React.Component{
    constructor(){
        super();
    this.state = {
        image :[
            "orange.jpg",
            "guava.jpg",
            "mango.jpg"
        ], idx:0
    }
}

    imageMethod=()=>{
        this.setState({
            idx: this.state.idx + 1
        })
    }

    render(){
        return(
            <div>
                <img style={{width:300, height:300}} src={this.state.image[this.state.idx]} />
                <button onClick={this.imageMethod}>Click</button>
            </div>
        )
    }
}

export default ExampleThree;