import React from 'react';

function FunctionalComponent(props){
    return(
        <div>{props.name}</div>
    )
}

export default FunctionalComponent;