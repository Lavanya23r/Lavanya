import React, { Component } from 'react'
import Parent from './Parent';

class GrandPaa extends Component {
 constructor(){
     super();
     this.state = {
         type:"Fruits"
     }
 }

  render() {
    return (
      <div className='grand'>
      <h2>Grandpaa</h2>
      <h3>{this.state.type}</h3>
      <img src="apple.jpg" width="250" height="130" />
      <Parent toparent = {this.state.type} />
      </div>
    )
  }
}

export default GrandPaa;