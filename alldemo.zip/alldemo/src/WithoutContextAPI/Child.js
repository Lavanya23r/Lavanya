import React, { Component } from 'react'

class Child extends Component {
  render() {
    return (
        <div className='child'>
        <h1>Child</h1>
        <h3>{this.props.tochild}</h3>
        <img src="mango.jpg" width="250" height="130" />
        </div>
    )
  }
}

export default Child