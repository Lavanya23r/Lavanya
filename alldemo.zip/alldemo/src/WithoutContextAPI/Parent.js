import React, { Component } from 'react'
import Child from './Child'

class Parent extends Component {
  render() {
    return (
        <div className='parent'>
        <h1>Parent</h1>
        <h3>{this.props.toparent}</h3>
        <img src="orange.jpg" width="250" height="130" />
        <Child tochild={this.props.toparent} />
        </div>
    )
  }
}

export default Parent