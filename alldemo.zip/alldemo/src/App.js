
import ClassComponent from './ClassComponent';
import FormHandling from './FormHandling/FormHandling';
import LifeCycle from './LifecycleComponents/LifeCycle';
import One from './Props/One';
import ExampleOne from './State/ExampleOne';
import ExampleThree from './State/ExampleThree';
import ExampleTwo from './State/ExampleTwo';
import PrevStatecomp from './State/PrevStatecomp';
import Child from './WithoutContextAPI/Child';
import GrandPaa from './WithoutContextAPI/GrandPaa';
import Parent from './WithoutContextAPI/Parent';
import GrandParent from './WithContextAPI/GrandParent';
import ToParent from './WithContextAPI/ToParent';
import ToChild from './WithContextAPI/ToChild';
import Button from './HigherOrderComponent/Button';
import Mouse from './HigherOrderComponent/Mouse';
import MouseOne from './HigherOrderComponent/MouseOne';
import Routing from './Routing/Routing';
import Products from './Routing/Products';
import ProductItems from './Routing/ProductItems';
import ChildRoutingProducts from './Routing/ChildRoutingProducts';
import GetRequest from './HTTPrequests/GetRequest';
import PostRequest from './HTTPrequests/PostRequest';
import Course from './ErrorBoundary/Course';
import { EroorBound } from './ErrorBoundary/EroorBound';

function App() {
  return (
    <div>
    <h5>All frontend frameworks</h5>
    <Course coursePassing='React'/>
    <EroorBound>
    <Course coursePassing='Angular'/>
    </EroorBound>
    <Course coursePassing='Vue Js'/>
    <EroorBound>
    <Course coursePassing='Java'/>
    </EroorBound>
    
     
    </div>
  );
}

export default App;
