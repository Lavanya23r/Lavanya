import React from 'react'

function Course({coursePassing}) {
    if(coursePassing === 'Java'){
        throw new Error('Java is not frontend framework')
    }
    return (
    <div>{coursePassing}</div>
    )
}

export default Course